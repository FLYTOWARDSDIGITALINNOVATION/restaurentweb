import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Package, Wallet, User, HelpCircle, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

const Sidebar: React.FC = () => {
  const { logout, user } = useAuth();
  
  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: Home },
    { name: 'Orders', path: '/dashboard/orders', icon: Package },
    { name: 'Earnings', path: '/dashboard/earnings', icon: Wallet },
    { name: 'Profile', path: '/dashboard/profile', icon: User },
    { name: 'Help', path: '/dashboard/help', icon: HelpCircle },
  ];
  
  return (
    <div className="h-full bg-white border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 flex items-center">
        <motion.div 
          className="h-10 w-10 rounded-lg bg-primary-500 flex items-center justify-center"
          whileHover={{ rotate: 5 }}
        >
          <Package size={24} className="text-white" />
        </motion.div>
        <span className="ml-3 text-xl font-bold text-gray-900">DeliveryPro</span>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                isActive
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
          >
            <item.icon size={20} className="flex-shrink-0 mr-3" />
            {item.name}
          </NavLink>
        ))}
      </nav>
      
      {/* User Profile Summary */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center">
          {user?.profileImage ? (
            <img 
              src={user.profileImage} 
              alt={user.name} 
              className="h-10 w-10 rounded-full object-cover"
            />
          ) : (
            <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
              <User size={20} className="text-gray-500" />
            </div>
          )}
          
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900">{user?.name}</p>
            <p className="text-xs text-gray-500">{user?.email}</p>
          </div>
        </div>
        
        <button
          onClick={logout}
          className="mt-4 w-full flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
        >
          <LogOut size={16} className="mr-2" />
          Sign Out
        </button>
      </div>
    </div>
  );
};

export default Sidebar;