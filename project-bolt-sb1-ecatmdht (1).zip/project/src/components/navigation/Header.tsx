import React from 'react';
import { Menu, Bell, UserCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface HeaderProps {
  onMenuButtonClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuButtonClick }) => {
  const { user, toggleAvailability } = useAuth();
  
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <button
            type="button"
            className="md:hidden p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
            onClick={onMenuButtonClick}
          >
            <Menu size={24} />
          </button>
          
          <div className="ml-4 md:ml-0">
            <h1 className="text-lg font-semibold text-gray-900">DeliveryPro</h1>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          {/* Availability Toggle */}
          <div className="hidden sm:flex items-center">
            <span className="mr-2 text-sm font-medium text-gray-700">Status:</span>
            <button 
              onClick={toggleAvailability}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${user?.isAvailable ? 'bg-success-500' : 'bg-gray-300'}`}
            >
              <span 
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${user?.isAvailable ? 'translate-x-6' : 'translate-x-1'}`}
              />
            </button>
            <span className={`ml-2 text-sm font-medium ${user?.isAvailable ? 'text-success-700' : 'text-gray-500'}`}>
              {user?.isAvailable ? 'Available' : 'Offline'}
            </span>
          </div>
          
          {/* Notifications */}
          <motion.button 
            whileTap={{ scale: 0.95 }}
            className="p-2 rounded-full text-gray-500 hover:text-gray-900 hover:bg-gray-100 relative"
          >
            <Bell size={20} />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-primary-500 animate-ping-slow"></span>
          </motion.button>
          
          {/* Profile Menu */}
          <Link to="/dashboard/profile" className="flex items-center">
            {user?.profileImage ? (
              <img 
                src={user.profileImage} 
                alt={user.name} 
                className="h-8 w-8 rounded-full object-cover"
              />
            ) : (
              <UserCircle size={32} className="text-gray-400" />
            )}
            <span className="ml-2 text-sm font-medium text-gray-700 hidden sm:inline-block">
              {user?.name}
            </span>
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;