import React, { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  vehicle?: string;
  profileImage?: string;
  isAvailable: boolean;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  toggleAvailability: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize auth state from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    
    if (storedUser && token) {
      setUser(JSON.parse(storedUser));
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
    
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      // In a real implementation, this would call the backend API
      // For demo purposes, we're simulating a successful login
      const mockUser: User = {
        id: '1',
        name: 'John Delivery',
        email,
        phone: '555-123-4567',
        vehicle: 'Motorcycle',
        profileImage: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
        isAvailable: true
      };
      
      const mockToken = 'mock-jwt-token';
      
      // Set auth header for future requests
      axios.defaults.headers.common['Authorization'] = `Bearer ${mockToken}`;
      
      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(mockUser));
      localStorage.setItem('token', mockToken);
      
      setUser(mockUser);
    } catch (err) {
      setError('Invalid email or password');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData: any) => {
    try {
      setLoading(true);
      setError(null);
      
      // In a real implementation, this would call the backend API
      // For demo purposes, we're simulating a successful registration
      const mockUser: User = {
        id: '1',
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        vehicle: userData.vehicle,
        isAvailable: true
      };
      
      const mockToken = 'mock-jwt-token';
      
      // Set auth header for future requests
      axios.defaults.headers.common['Authorization'] = `Bearer ${mockToken}`;
      
      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(mockUser));
      localStorage.setItem('token', mockToken);
      
      setUser(mockUser);
    } catch (err) {
      setError('Registration failed. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    // Remove from localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    
    // Remove auth header
    delete axios.defaults.headers.common['Authorization'];
    
    // Update state
    setUser(null);
  };

  const updateProfile = async (userData: Partial<User>) => {
    try {
      setLoading(true);
      setError(null);
      
      // In a real implementation, this would call the backend API
      // For demo purposes, we're simulating a successful profile update
      const updatedUser = { ...user, ...userData };
      
      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      setUser(updatedUser as User);
    } catch (err) {
      setError('Profile update failed. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const toggleAvailability = async () => {
    try {
      if (!user) return;
      
      const updatedUser = { ...user, isAvailable: !user.isAvailable };
      
      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      setUser(updatedUser);
    } catch (err) {
      setError('Failed to update availability. Please try again.');
      console.error(err);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      error, 
      login, 
      register, 
      logout, 
      updateProfile,
      toggleAvailability
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};