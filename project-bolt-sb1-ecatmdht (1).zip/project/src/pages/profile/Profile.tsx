import React, { useState } from 'react';
import { User, Mail, Phone, Truck, Camera, Shield, CreditCard, MapPin, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

const Profile: React.FC = () => {
  const { user, updateProfile, logout } = useAuth();
  
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    vehicle: user?.vehicle || 'Motorcycle',
    address: '123 Partner St, Delivery City',
    bankAccount: '•••• •••• •••• 4567',
    licenseNumber: 'DL12345678',
    emergencyContact: '555-987-1234'
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile(formData);
    setIsEditing(false);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
        
        {!isEditing ? (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsEditing(true)}
            className="btn-primary"
          >
            Edit Profile
          </motion.button>
        ) : (
          <div className="flex space-x-2">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsEditing(false)}
              className="btn-outline"
            >
              Cancel
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleSubmit}
              className="btn-primary"
            >
              Save Changes
            </motion.button>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Overview */}
        <div className="card p-6 text-center">
          <div className="relative mx-auto w-32 h-32 mb-4">
            {user?.profileImage ? (
              <img 
                src={user.profileImage} 
                alt={user.name} 
                className="w-32 h-32 rounded-full object-cover"
              />
            ) : (
              <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
                <User size={48} className="text-gray-400" />
              </div>
            )}
            
            {isEditing && (
              <div className="absolute bottom-0 right-0 p-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center"
                >
                  <Camera size={16} />
                </motion.button>
              </div>
            )}
          </div>
          
          <h2 className="text-xl font-semibold">{user?.name}</h2>
          <p className="text-gray-500">Delivery Partner</p>
          
          <div className="mt-6 space-y-2">
            <div className="flex items-center px-4 py-2 bg-gray-50 rounded-lg">
              <Mail size={16} className="text-gray-400 mr-3" />
              <span className="text-sm">{user?.email}</span>
            </div>
            
            <div className="flex items-center px-4 py-2 bg-gray-50 rounded-lg">
              <Phone size={16} className="text-gray-400 mr-3" />
              <span className="text-sm">{user?.phone}</span>
            </div>
            
            <div className="flex items-center px-4 py-2 bg-gray-50 rounded-lg">
              <Truck size={16} className="text-gray-400 mr-3" />
              <span className="text-sm">{user?.vehicle}</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={logout}
              className="btn-outline border-error-500 text-error-600 w-full"
            >
              <LogOut size={16} />
              Sign Out
            </motion.button>
          </div>
        </div>
        
        {/* Profile Details */}
        <div className="lg:col-span-2">
          {/* Personal Information */}
          <div className="card p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Personal Information</h2>
            
            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <User size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="vehicle" className="block text-sm font-medium text-gray-700 mb-1">
                    Vehicle Type
                  </label>
                  <div className="relative">
                    <Truck size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <select
                      id="vehicle"
                      name="vehicle"
                      value={formData.vehicle}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9 pr-10 appearance-none"
                    >
                      <option value="Motorcycle">Motorcycle</option>
                      <option value="Bicycle">Bicycle</option>
                      <option value="Car">Car</option>
                      <option value="Scooter">Scooter</option>
                      <option value="On Foot">On Foot</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="emergencyContact" className="block text-sm font-medium text-gray-700 mb-1">
                    Emergency Contact
                  </label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="tel"
                      id="emergencyContact"
                      name="emergencyContact"
                      value={formData.emergencyContact}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="input pl-9"
                    />
                  </div>
                </div>
              </div>
            </form>
          </div>
          
          {/* Documents & Verification */}
          <div className="card p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Documents & Verification</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Shield size={20} className="text-success-500 mr-3" />
                  <div>
                    <p className="font-medium">Driver's License</p>
                    <p className="text-sm text-gray-500">{formData.licenseNumber}</p>
                  </div>
                </div>
                <span className="badge-success">Verified</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Shield size={20} className="text-success-500 mr-3" />
                  <div>
                    <p className="font-medium">Identity Verification</p>
                    <p className="text-sm text-gray-500">Government ID</p>
                  </div>
                </div>
                <span className="badge-success">Verified</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Shield size={20} className="text-warning-500 mr-3" />
                  <div>
                    <p className="font-medium">Vehicle Registration</p>
                    <p className="text-sm text-gray-500">Motorcycle</p>
                  </div>
                </div>
                <span className="badge-warning">Pending</span>
              </div>
            </div>
          </div>
          
          {/* Payment Information */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold mb-4">Payment Information</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <CreditCard size={20} className="text-gray-400 mr-3" />
                  <div>
                    <p className="font-medium">Bank Account</p>
                    <p className="text-sm text-gray-500">{formData.bankAccount}</p>
                  </div>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="text-sm text-secondary-600 font-medium"
                >
                  Change
                </motion.button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <CreditCard size={20} className="text-gray-400 mr-3" />
                  <div>
                    <p className="font-medium">Payment Schedule</p>
                    <p className="text-sm text-gray-500">Weekly (Monday)</p>
                  </div>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="text-sm text-secondary-600 font-medium"
                >
                  Change
                </motion.button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;