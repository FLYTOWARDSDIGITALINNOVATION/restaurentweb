import React, { useState } from 'react';
import { Calendar, DollarSign, TrendingUp, FileText, Filter, Download } from 'lucide-react';
import { motion } from 'framer-motion';

// Sample earnings data
const earningsData = {
  thisWeek: '$245.80',
  lastWeek: '$198.50',
  thisMonth: '$830.25',
  pendingPayouts: '$120.75',
  completedDeliveries: 45,
  deliveriesThisWeek: 18,
  averagePerDelivery: '$13.65',
  transactions: [
    { id: 1, date: '2025-04-10', type: 'Delivery Earnings', orderId: 'ORD-4839', amount: '$7.99' },
    { id: 2, date: '2025-04-10', type: 'Delivery Earnings', orderId: 'ORD-4838', amount: '$6.50' },
    { id: 3, date: '2025-04-10', type: 'Tip', orderId: 'ORD-4838', amount: '$2.00' },
    { id: 4, date: '2025-04-10', type: 'Delivery Earnings', orderId: 'ORD-4837', amount: '$8.75' },
    { id: 5, date: '2025-04-10', type: 'Tip', orderId: 'ORD-4837', amount: '$4.00' },
    { id: 6, date: '2025-04-09', type: 'Delivery Earnings', orderId: 'ORD-4836', amount: '$5.25' },
    { id: 7, date: '2025-04-09', type: 'Delivery Earnings', orderId: 'ORD-4835', amount: '$6.50' },
    { id: 8, date: '2025-04-09', type: 'Tip', orderId: 'ORD-4835', amount: '$3.00' },
    { id: 9, date: '2025-04-09', type: 'Delivery Earnings', orderId: 'ORD-4834', amount: '$7.99' },
    { id: 10, date: '2025-04-08', type: 'Delivery Earnings', orderId: 'ORD-4833', amount: '$4.75' },
    { id: 11, date: '2025-04-08', type: 'Tip', orderId: 'ORD-4833', amount: '$2.00' }
  ],
  dailyEarnings: [
    { date: 'Mon', amount: 38.50 },
    { date: 'Tue', amount: 42.75 },
    { date: 'Wed', amount: 35.20 },
    { date: 'Thu', amount: 51.60 },
    { date: 'Fri', amount: 47.25 },
    { date: 'Sat', amount: 30.50 },
    { date: 'Sun', amount: 0 }
  ]
};

const Earnings: React.FC = () => {
  const [dateFilter, setDateFilter] = useState('this-week');
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  // Get transactions based on filter
  const getFilteredTransactions = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const thisWeekStart = new Date(today);
    thisWeekStart.setDate(today.getDate() - today.getDay());
    
    const lastWeekStart = new Date(thisWeekStart);
    lastWeekStart.setDate(lastWeekStart.getDate() - 7);
    
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    
    return earningsData.transactions.filter(transaction => {
      const transactionDate = new Date(transaction.date);
      
      if (dateFilter === 'today') {
        return transactionDate >= today;
      } else if (dateFilter === 'this-week') {
        return transactionDate >= thisWeekStart;
      } else if (dateFilter === 'last-week') {
        return transactionDate >= lastWeekStart && transactionDate < thisWeekStart;
      } else if (dateFilter === 'this-month') {
        return transactionDate >= thisMonthStart;
      } else {
        return true;
      }
    });
  };
  
  const filteredTransactions = getFilteredTransactions();
  
  // Chart bars
  const maxAmount = Math.max(...earningsData.dailyEarnings.map(day => day.amount));
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Earnings</h1>
        
        <div className="flex space-x-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="btn-outline flex-nowrap whitespace-nowrap"
          >
            <Calendar size={16} />
            View Payment Schedule
          </motion.button>
          
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="btn-outline flex-nowrap whitespace-nowrap hidden sm:flex"
          >
            <Download size={16} />
            Download Report
          </motion.button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">This Week</p>
              <p className="text-2xl font-bold text-gray-900">{earningsData.thisWeek}</p>
            </div>
            <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
              <DollarSign size={20} className="text-primary-600" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <TrendingUp size={14} className="text-success-500 mr-1" />
            <span className="text-success-700">24% more</span>
            <span className="text-gray-500 ml-1">than last week</span>
          </div>
        </div>
        
        <div className="card p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">This Month</p>
              <p className="text-2xl font-bold text-gray-900">{earningsData.thisMonth}</p>
            </div>
            <div className="h-10 w-10 rounded-full bg-secondary-100 flex items-center justify-center">
              <Calendar size={20} className="text-secondary-600" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <span className="text-gray-500">Month in progress</span>
          </div>
        </div>
        
        <div className="card p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">Pending Payout</p>
              <p className="text-2xl font-bold text-gray-900">{earningsData.pendingPayouts}</p>
            </div>
            <div className="h-10 w-10 rounded-full bg-warning-100 flex items-center justify-center">
              <FileText size={20} className="text-warning-600" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <span className="text-gray-500">Next payout on April 15</span>
          </div>
        </div>
        
        <div className="card p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">Avg. Per Delivery</p>
              <p className="text-2xl font-bold text-gray-900">{earningsData.averagePerDelivery}</p>
            </div>
            <div className="h-10 w-10 rounded-full bg-success-100 flex items-center justify-center">
              <TrendingUp size={20} className="text-success-600" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <span className="text-gray-500">{earningsData.completedDeliveries} total deliveries</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="card p-5 lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-semibold text-lg">Weekly Earnings</h2>
            <div className="relative">
              <Filter size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="pl-9 pr-8 py-1 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent appearance-none"
              >
                <option value="today">Today</option>
                <option value="this-week">This Week</option>
                <option value="last-week">Last Week</option>
                <option value="this-month">This Month</option>
                <option value="all">All Time</option>
              </select>
            </div>
          </div>
          
          {/* Bar Chart */}
          <div className="h-64">
            <div className="flex h-full items-end justify-between">
              {earningsData.dailyEarnings.map((day, index) => (
                <div key={index} className="flex flex-col items-center w-1/7">
                  <div 
                    className="w-12 bg-primary-500 rounded-t-md transition-all duration-500" 
                    style={{ 
                      height: day.amount > 0 ? `${(day.amount / maxAmount) * 200}px` : '4px',
                      opacity: day.amount > 0 ? 1 : 0.3
                    }}
                  ></div>
                  <div className="text-xs mt-2 text-gray-500">{day.date}</div>
                  <div className="text-xs font-medium">${day.amount.toFixed(2)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Recent Transactions */}
        <div className="card p-5">
          <h2 className="font-semibold text-lg mb-4">Recent Transactions</h2>
          
          <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((transaction) => (
                <div key={transaction.id} className="flex justify-between pb-3 border-b border-gray-100 last:border-b-0 last:pb-0">
                  <div>
                    <p className="font-medium text-sm">{transaction.type}</p>
                    <div className="flex text-xs text-gray-500 space-x-2">
                      <span>{formatDate(transaction.date)}</span>
                      <span>•</span>
                      <span>{transaction.orderId}</span>
                    </div>
                  </div>
                  <p className={`font-medium text-sm ${transaction.type === 'Tip' ? 'text-success-600' : ''}`}>
                    {transaction.amount}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 text-sm py-4">No transactions found for the selected period.</p>
            )}
          </div>
          
          <div className="mt-4 text-center">
            <button className="text-sm font-medium text-secondary-600 hover:text-secondary-700">
              View all transactions
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Earnings;