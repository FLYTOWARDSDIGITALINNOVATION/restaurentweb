import React, { useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { Package, User, Mail, Lock, Phone, Truck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    vehicle: 'motorcycle'
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const { register, user, loading, error } = useAuth();
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    // Name validation
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    // Email validation
    if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Valid email is required';
    }
    
    // Phone validation
    if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'Valid phone number is required';
    }
    
    // Password validation
    if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    // Confirm password
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      const { confirmPassword, ...registerData } = formData;
      await register(registerData);
    }
  };
  
  // Redirect if already logged in
  if (user) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <motion.div 
            className="mx-auto h-14 w-14 rounded-xl bg-primary-500 flex items-center justify-center"
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Package size={32} className="text-white" />
          </motion.div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Create your account</h2>
          <p className="mt-2 text-sm text-gray-600">
            Or{' '}
            <Link to="/login" className="font-medium text-primary-600 hover:text-primary-500">
              sign in to your existing account
            </Link>
          </p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-error-50 p-4 rounded-lg text-error-700 text-sm">
              {error}
            </div>
          )}
          
          <div className="rounded-md shadow-sm space-y-4">
            <div className="relative">
              <label htmlFor="name" className="sr-only">
                Full name
              </label>
              <User 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <input
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                required
                value={formData.name}
                onChange={handleChange}
                className={`input pl-10 ${errors.name ? 'border-error-500 ring-1 ring-error-500' : ''}`}
                placeholder="Full name"
              />
              {errors.name && <p className="mt-1 text-xs text-error-700">{errors.name}</p>}
            </div>
            
            <div className="relative">
              <label htmlFor="email" className="sr-only">
                Email address
              </label>
              <Mail 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={formData.email}
                onChange={handleChange}
                className={`input pl-10 ${errors.email ? 'border-error-500 ring-1 ring-error-500' : ''}`}
                placeholder="Email address"
              />
              {errors.email && <p className="mt-1 text-xs text-error-700">{errors.email}</p>}
            </div>
            
            <div className="relative">
              <label htmlFor="phone" className="sr-only">
                Phone number
              </label>
              <Phone 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <input
                id="phone"
                name="phone"
                type="tel"
                autoComplete="tel"
                required
                value={formData.phone}
                onChange={handleChange}
                className={`input pl-10 ${errors.phone ? 'border-error-500 ring-1 ring-error-500' : ''}`}
                placeholder="Phone number"
              />
              {errors.phone && <p className="mt-1 text-xs text-error-700">{errors.phone}</p>}
            </div>
            
            <div className="relative">
              <label htmlFor="vehicle" className="sr-only">
                Vehicle type
              </label>
              <Truck 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <select
                id="vehicle"
                name="vehicle"
                required
                value={formData.vehicle}
                onChange={handleChange}
                className="input pl-10 pr-10 appearance-none"
              >
                <option value="motorcycle">Motorcycle</option>
                <option value="bicycle">Bicycle</option>
                <option value="car">Car</option>
                <option value="scooter">Scooter</option>
                <option value="walk">On Foot</option>
              </select>
            </div>
            
            <div className="relative">
              <label htmlFor="password" className="sr-only">
                Password
              </label>
              <Lock 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                value={formData.password}
                onChange={handleChange}
                className={`input pl-10 ${errors.password ? 'border-error-500 ring-1 ring-error-500' : ''}`}
                placeholder="Password"
              />
              {errors.password && <p className="mt-1 text-xs text-error-700">{errors.password}</p>}
            </div>
            
            <div className="relative">
              <label htmlFor="confirmPassword" className="sr-only">
                Confirm password
              </label>
              <Lock 
                size={18} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
              />
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                autoComplete="new-password"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                className={`input pl-10 ${errors.confirmPassword ? 'border-error-500 ring-1 ring-error-500' : ''}`}
                placeholder="Confirm password"
              />
              {errors.confirmPassword && <p className="mt-1 text-xs text-error-700">{errors.confirmPassword}</p>}
            </div>
          </div>

          <div>
            <div className="flex items-center">
              <input
                id="terms"
                name="terms"
                type="checkbox"
                required
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
                I agree to the <a href="#" className="text-primary-600 hover:text-primary-500">Terms</a> and <a href="#" className="text-primary-600 hover:text-primary-500">Privacy Policy</a>
              </label>
            </div>
          </div>

          <div>
            <motion.button
              whileTap={{ scale: 0.95 }}
              type="submit"
              className="btn-primary w-full"
              disabled={loading}
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                </div>
              ) : (
                'Create account'
              )}
            </motion.button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;