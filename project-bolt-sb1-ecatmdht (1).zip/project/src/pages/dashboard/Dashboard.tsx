import React from 'react';
import { Link } from 'react-router-dom';
import { Package, TrendingUp, DollarSign, Clock, MapPin, Car } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

// Sample data for demo purposes
const stats = [
  { id: 1, name: 'Today\'s Earnings', value: '$78.50', icon: DollarSign, color: 'bg-secondary-50 text-secondary-700' },
  { id: 2, name: 'Completed Orders', value: '7', icon: Package, color: 'bg-primary-50 text-primary-700' },
  { id: 3, name: 'Avg. Delivery Time', value: '24 min', icon: Clock, color: 'bg-warning-50 text-warning-700' },
  { id: 4, name: 'Total Distance', value: '42 km', icon: Car, color: 'bg-success-50 text-success-700' },
];

// Sample data for active order
const activeOrder = {
  id: 'ORD-4839',
  restaurant: 'Burger Express',
  restaurantAddress: '123 Main St, Downtown',
  customer: 'Sarah Johnson',
  customerAddress: '456 Oak Ave, Uptown',
  items: [
    'Double Cheeseburger x1',
    'French Fries (Large) x1',
    'Chocolate Milkshake x1'
  ],
  total: '$24.99',
  status: 'In Progress',
  estimatedDelivery: '15 minutes',
  paymentMethod: 'Card'
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };
  
  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-500 rounded-xl p-6 text-white shadow-lg">
        <h1 className="text-2xl font-bold">Welcome back, {user?.name.split(' ')[0]}!</h1>
        <p className="mt-2 opacity-90">Ready to make some deliveries today? Check your active orders below.</p>
      </div>
      
      {/* Stats */}
      <motion.div 
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {stats.map((stat) => (
          <motion.div
            key={stat.id}
            className="card p-4 flex items-center"
            variants={item}
          >
            <div className={`w-12 h-12 rounded-full ${stat.color} flex items-center justify-center`}>
              <stat.icon size={24} />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">{stat.name}</p>
              <p className="text-xl font-semibold">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Order */}
        <div className="lg:col-span-2">
          <h2 className="text-lg font-semibold mb-4">Active Order</h2>
          <div className="card">
            <div className="p-5 border-b border-gray-100">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Order #{activeOrder.id}</h3>
                  <span className="badge-success mt-1">{activeOrder.status}</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">{activeOrder.total}</p>
                  <p className="text-sm text-gray-500">{activeOrder.paymentMethod}</p>
                </div>
              </div>
            </div>
            
            <div className="p-5 space-y-4">
              {/* Restaurant */}
              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                    <Package size={16} className="text-primary-600" />
                  </div>
                </div>
                <div className="ml-4">
                  <h4 className="font-medium">Pickup</h4>
                  <p className="text-gray-800">{activeOrder.restaurant}</p>
                  <p className="text-sm text-gray-500">{activeOrder.restaurantAddress}</p>
                </div>
              </div>
              
              {/* Customer */}
              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-secondary-100 flex items-center justify-center">
                    <MapPin size={16} className="text-secondary-600" />
                  </div>
                </div>
                <div className="ml-4">
                  <h4 className="font-medium">Delivery</h4>
                  <p className="text-gray-800">{activeOrder.customer}</p>
                  <p className="text-sm text-gray-500">{activeOrder.customerAddress}</p>
                </div>
              </div>
              
              {/* Order Items */}
              <div className="border-t border-gray-100 pt-4">
                <h4 className="font-medium mb-2">Order Items</h4>
                <ul className="space-y-1">
                  {activeOrder.items.map((item, index) => (
                    <li key={index} className="text-sm text-gray-700">• {item}</li>
                  ))}
                </ul>
              </div>
              
              {/* Actions */}
              <div className="flex space-x-2 pt-3">
                <Link to={`/dashboard/orders/1`} className="btn-primary flex-1">
                  View Details
                </Link>
                <motion.button 
                  whileTap={{ scale: 0.95 }}
                  className="btn-outline border-primary-500 text-primary-600 flex-1"
                >
                  Navigate
                </motion.button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Upcoming Orders */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
          <div className="card divide-y divide-gray-100">
            <div className="p-4 flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                <Package size={18} className="text-gray-600" />
              </div>
              <div className="ml-3">
                <p className="font-medium">Order #ORD-4838 completed</p>
                <p className="text-xs text-gray-500">1 hour ago</p>
              </div>
            </div>
            
            <div className="p-4 flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                <DollarSign size={18} className="text-gray-600" />
              </div>
              <div className="ml-3">
                <p className="font-medium">Received payment of $18.50</p>
                <p className="text-xs text-gray-500">2 hours ago</p>
              </div>
            </div>
            
            <div className="p-4 flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                <TrendingUp size={18} className="text-gray-600" />
              </div>
              <div className="ml-3">
                <p className="font-medium">Performance rating increased</p>
                <p className="text-xs text-gray-500">4 hours ago</p>
              </div>
            </div>
            
            <div className="p-4 flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                <Package size={18} className="text-gray-600" />
              </div>
              <div className="ml-3">
                <p className="font-medium">Order #ORD-4837 completed</p>
                <p className="text-xs text-gray-500">6 hours ago</p>
              </div>
            </div>
            
            <div className="p-4 text-center">
              <Link to="/dashboard/orders" className="text-sm font-medium text-secondary-600 hover:text-secondary-700">
                View all activity
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;