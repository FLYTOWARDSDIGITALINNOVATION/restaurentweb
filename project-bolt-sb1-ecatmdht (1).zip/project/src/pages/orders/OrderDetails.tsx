import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Package, MapPin, PhoneCall, Clock, Navigation, CheckCircle, XCircle, User } from 'lucide-react';
import { motion } from 'framer-motion';

// Sample order data
const orderDetails = {
  id: '1',
  orderId: 'ORD-4839',
  status: 'In Progress',
  date: '2025-04-10T14:30:00',
  estimatedDeliveryTime: '15 minutes',
  paymentMethod: 'Card',
  total: '$24.99',
  deliveryFee: '$3.99',
  tip: '$4.00',
  yourEarnings: '$7.99',
  restaurant: {
    name: 'Burger Express',
    address: '123 Main St, Downtown',
    phone: '(555) 123-4567',
    notes: 'Ask for order at the pickup counter.'
  },
  customer: {
    name: 'Sarah Johnson',
    address: '456 Oak Ave, Uptown',
    phone: '(555) 987-6543',
    notes: 'Please leave at the door. Apartment 3B, second floor.'
  },
  items: [
    { id: 1, name: 'Double Cheeseburger', quantity: 1, price: '$10.99', notes: 'No pickles' },
    { id: 2, name: 'French Fries (Large)', quantity: 1, price: '$4.99', notes: '' },
    { id: 3, name: 'Chocolate Milkshake', quantity: 1, price: '$5.99', notes: 'Extra whipped cream' }
  ],
  timeline: [
    { id: 1, status: 'Order Placed', time: '2:30 PM', completed: true },
    { id: 2, status: 'Restaurant Preparing', time: '2:35 PM', completed: true },
    { id: 3, status: 'Ready for Pickup', time: '2:45 PM', completed: true },
    { id: 4, status: 'On the Way', time: '2:50 PM', completed: false },
    { id: 5, status: 'Delivered', time: '', completed: false }
  ]
};

const OrderDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [currentStatus, setCurrentStatus] = useState('In Progress');
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Handle status update
  const updateStatus = (newStatus: string) => {
    setCurrentStatus(newStatus);
    // In a real app, this would make an API call to update the order status
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Order #{orderDetails.orderId}</h1>
          <p className="text-sm text-gray-500">{formatDate(orderDetails.date)}</p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {currentStatus === 'In Progress' && (
            <>
              <motion.button
                whileTap={{ scale: 0.95 }}
                className="btn-primary"
                onClick={() => updateStatus('Delivered')}
              >
                <CheckCircle size={16} />
                Mark as Delivered
              </motion.button>
              
              <motion.button
                whileTap={{ scale: 0.95 }}
                className="btn-outline border-error-500 text-error-600"
                onClick={() => updateStatus('Cancelled')}
              >
                <XCircle size={16} />
                Cancel Delivery
              </motion.button>
            </>
          )}
          
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="btn-secondary"
          >
            <Navigation size={16} />
            Navigate
          </motion.button>
        </div>
      </div>
      
      {/* Status Badge */}
      <div className="inline-block">
        <span className={`badge ${
          currentStatus === 'Delivered' 
            ? 'badge-success' 
            : currentStatus === 'Cancelled'
              ? 'badge-error'
              : 'badge-warning'
        }`}>
          {currentStatus}
        </span>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Locations */}
          <div className="card space-y-4 p-5">
            <h2 className="font-semibold text-lg">Delivery Information</h2>
            
            {/* Restaurant */}
            <div className="flex">
              <div className="flex-shrink-0 mt-1">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <Package size={20} className="text-primary-600" />
                </div>
              </div>
              <div className="ml-4">
                <h3 className="font-medium">Pickup from</h3>
                <p className="text-gray-800">{orderDetails.restaurant.name}</p>
                <p className="text-sm text-gray-500">{orderDetails.restaurant.address}</p>
                
                <div className="mt-2 flex flex-wrap gap-2">
                  <a 
                    href={`tel:${orderDetails.restaurant.phone}`} 
                    className="inline-flex items-center text-sm text-secondary-600"
                  >
                    <PhoneCall size={14} className="mr-1" />
                    {orderDetails.restaurant.phone}
                  </a>
                  
                  <button className="inline-flex items-center text-sm text-secondary-600">
                    <Navigation size={14} className="mr-1" />
                    Directions
                  </button>
                </div>
                
                {orderDetails.restaurant.notes && (
                  <div className="mt-2 text-sm bg-gray-50 p-2 rounded-md">
                    <span className="font-medium">Note: </span>
                    {orderDetails.restaurant.notes}
                  </div>
                )}
              </div>
            </div>
            
            {/* Customer */}
            <div className="flex pt-2 border-t border-gray-100">
              <div className="flex-shrink-0 mt-1">
                <div className="w-10 h-10 rounded-full bg-secondary-100 flex items-center justify-center">
                  <MapPin size={20} className="text-secondary-600" />
                </div>
              </div>
              <div className="ml-4">
                <h3 className="font-medium">Deliver to</h3>
                <p className="text-gray-800">{orderDetails.customer.name}</p>
                <p className="text-sm text-gray-500">{orderDetails.customer.address}</p>
                
                <div className="mt-2 flex flex-wrap gap-2">
                  <a 
                    href={`tel:${orderDetails.customer.phone}`} 
                    className="inline-flex items-center text-sm text-secondary-600"
                  >
                    <PhoneCall size={14} className="mr-1" />
                    {orderDetails.customer.phone}
                  </a>
                  
                  <button className="inline-flex items-center text-sm text-secondary-600">
                    <Navigation size={14} className="mr-1" />
                    Directions
                  </button>
                </div>
                
                {orderDetails.customer.notes && (
                  <div className="mt-2 text-sm bg-gray-50 p-2 rounded-md">
                    <span className="font-medium">Note: </span>
                    {orderDetails.customer.notes}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Order Items */}
          <div className="card p-5">
            <h2 className="font-semibold text-lg mb-4">Order Items</h2>
            
            <div className="space-y-3">
              {orderDetails.items.map((item) => (
                <div key={item.id} className="flex justify-between pb-3 border-b border-gray-100 last:border-b-0 last:pb-0">
                  <div>
                    <p className="font-medium">{item.name} × {item.quantity}</p>
                    {item.notes && (
                      <p className="text-sm text-gray-500">Note: {item.notes}</p>
                    )}
                  </div>
                  <p className="font-medium">{item.price}</p>
                </div>
              ))}
            </div>
          </div>
          
          {/* Delivery Timeline */}
          <div className="card p-5">
            <h2 className="font-semibold text-lg mb-4">Delivery Timeline</h2>
            
            <div className="relative">
              {/* Vertical Line */}
              <div className="absolute top-0 bottom-0 left-3 w-0.5 bg-gray-200"></div>
              
              {/* Timeline Steps */}
              <div className="space-y-6">
                {orderDetails.timeline.map((step, index) => (
                  <div key={step.id} className="flex relative z-10">
                    <div className={`h-6 w-6 rounded-full flex items-center justify-center ${
                      step.completed ? 'bg-primary-500' : 'bg-gray-200'
                    }`}>
                      {step.completed ? (
                        <CheckCircle size={14} className="text-white" />
                      ) : (
                        <Clock size={14} className="text-gray-500" />
                      )}
                    </div>
                    <div className="ml-4">
                      <p className="font-medium">{step.status}</p>
                      <p className="text-sm text-gray-500">
                        {step.time || 'Pending'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="space-y-6">
          <div className="card p-5">
            <h2 className="font-semibold text-lg mb-4">Order Summary</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Order Subtotal</span>
                <span>{orderDetails.total}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Delivery Fee</span>
                <span>{orderDetails.deliveryFee}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Customer Tip</span>
                <span>{orderDetails.tip}</span>
              </div>
              
              <div className="pt-3 border-t border-gray-200 flex justify-between font-medium">
                <span>Your Earnings</span>
                <span className="text-primary-600">{orderDetails.yourEarnings}</span>
              </div>
            </div>
          </div>
          
          <div className="card p-5">
            <h2 className="font-semibold text-lg mb-4">Customer Information</h2>
            
            <div className="flex items-center mb-4">
              <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center">
                <User size={24} className="text-gray-500" />
              </div>
              <div className="ml-3">
                <p className="font-medium">{orderDetails.customer.name}</p>
                <p className="text-sm text-gray-500">Customer</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center">
                <PhoneCall size={16} className="text-gray-400 mr-2" />
                <a href={`tel:${orderDetails.customer.phone}`} className="text-sm">
                  {orderDetails.customer.phone}
                </a>
              </div>
              
              <div className="flex">
                <MapPin size={16} className="text-gray-400 mr-2 flex-shrink-0 mt-0.5" />
                <p className="text-sm">{orderDetails.customer.address}</p>
              </div>
            </div>
          </div>
          
          <div className="card p-5">
            <h2 className="font-semibold text-lg mb-4">Delivery Information</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Estimated Time</span>
                <span>{orderDetails.estimatedDeliveryTime}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Payment Method</span>
                <span>{orderDetails.paymentMethod}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Order Date</span>
                <span>{formatDate(orderDetails.date)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetails;