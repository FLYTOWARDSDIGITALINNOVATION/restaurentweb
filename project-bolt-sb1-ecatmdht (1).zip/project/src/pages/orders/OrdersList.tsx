import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

// Sample orders data
const ordersData = [
  {
    id: '1',
    orderId: 'ORD-4839',
    restaurant: 'Burger Express',
    customer: 'Sarah Johnson',
    date: '2025-04-10T14:30:00',
    total: '$24.99',
    status: 'In Progress'
  },
  {
    id: '2',
    orderId: 'ORD-4838',
    restaurant: 'Pizza Paradise',
    customer: 'Michael Brown',
    date: '2025-04-10T12:15:00',
    total: '$18.50',
    status: 'Completed'
  },
  {
    id: '3',
    orderId: 'ORD-4837',
    restaurant: 'Sushi World',
    customer: 'Jennifer Lee',
    date: '2025-04-10T10:45:00',
    total: '$32.75',
    status: 'Completed'
  },
  {
    id: '4',
    orderId: 'ORD-4836',
    restaurant: 'Taco Town',
    customer: 'David Wilson',
    date: '2025-04-09T19:20:00',
    total: '$15.25',
    status: 'Completed'
  },
  {
    id: '5',
    orderId: 'ORD-4835',
    restaurant: 'Noodle House',
    customer: 'Lisa Garcia',
    date: '2025-04-09T17:40:00',
    total: '$22.50',
    status: 'Completed'
  },
  {
    id: '6',
    orderId: 'ORD-4834',
    restaurant: 'Curry Corner',
    customer: 'Robert Taylor',
    date: '2025-04-09T14:10:00',
    total: '$29.99',
    status: 'Completed'
  },
  {
    id: '7',
    orderId: 'ORD-4833',
    restaurant: 'Salad Station',
    customer: 'Emily White',
    date: '2025-04-08T13:30:00',
    total: '$12.75',
    status: 'Completed'
  }
];

const OrdersList: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Filter orders based on search query and status filter
  const filteredOrders = ordersData.filter(order => {
    const matchesSearch = 
      order.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.restaurant.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = 
      statusFilter === 'all' || 
      order.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });
  
  // Helper function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
        
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          {/* Search */}
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search orders..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pl-10 w-full sm:w-64"
            />
          </div>
          
          {/* Filter */}
          <div className="relative w-full sm:w-auto">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="input pl-10 pr-10 appearance-none w-full"
            >
              <option value="all">All statuses</option>
              <option value="in progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Orders Table/Cards */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Desktop Table */}
        <div className="hidden md:block">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Order ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Restaurant
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date & Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">View</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <motion.tr 
                  key={order.id}
                  whileHover={{ backgroundColor: 'rgba(249, 250, 251, 0.5)' }}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {order.orderId}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.restaurant}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.customer}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(order.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {order.total}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`badge ${
                      order.status === 'Completed' 
                        ? 'badge-success' 
                        : 'badge-warning'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Link 
                      to={`/dashboard/orders/${order.id}`} 
                      className="text-secondary-600 hover:text-secondary-900"
                    >
                      View
                    </Link>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Mobile Cards */}
        <div className="md:hidden divide-y divide-gray-200">
          {filteredOrders.map((order) => (
            <motion.div 
              key={order.id}
              className="p-4"
              whileTap={{ backgroundColor: 'rgba(249, 250, 251, 0.5)' }}
            >
              <div className="flex justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">{order.orderId}</p>
                  <p className="text-sm text-gray-500">{order.restaurant}</p>
                </div>
                <span className={`badge ${
                  order.status === 'Completed' 
                    ? 'badge-success' 
                    : 'badge-warning'
                }`}>
                  {order.status}
                </span>
              </div>
              <div className="mt-2 flex justify-between items-end">
                <div>
                  <p className="text-xs text-gray-500">{formatDate(order.date)}</p>
                  <p className="text-sm font-medium">{order.total}</p>
                </div>
                <Link 
                  to={`/dashboard/orders/${order.id}`} 
                  className="text-secondary-600 flex items-center"
                >
                  View <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Empty State */}
        {filteredOrders.length === 0 && (
          <div className="py-10 text-center">
            <p className="text-gray-500">No orders found matching your criteria.</p>
          </div>
        )}
      </div>
      
      {/* Pagination */}
      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-500">
          Showing {filteredOrders.length} of {ordersData.length} orders
        </p>
        <div className="flex space-x-2">
          <button className="btn-outline px-3 py-1 text-sm">Previous</button>
          <button className="btn-primary px-3 py-1 text-sm">Next</button>
        </div>
      </div>
    </div>
  );
};

export default OrdersList;