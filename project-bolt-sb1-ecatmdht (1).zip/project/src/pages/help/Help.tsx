import React, { useState } from 'react';
import { Search, ChevronDown, MessageCircle, Phone, Mail, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// FAQ data
const faqData = [
  {
    id: 1,
    question: "How do I update my vehicle information?",
    answer: "You can update your vehicle information by going to your Profile page and clicking on 'Edit Profile'. From there, you can change your vehicle type and other details. Once done, click 'Save Changes' to update your information."
  },
  {
    id: 2,
    question: "When will I receive my payment?",
    answer: "Payments are processed every Monday for the previous week's deliveries. The funds typically take 1-2 business days to reflect in your bank account after processing. You can view your payment schedule and history in the Earnings section."
  },
  {
    id: 3,
    question: "What should I do if a customer is not available?",
    answer: "If a customer is not available for delivery, first try to contact them via the app or phone. Wait for 5 minutes at the delivery location. If they still don't respond, use the 'Can't Deliver' option in the app, select 'Customer Unavailable', and follow the instructions for returning the order."
  },
  {
    id: 4,
    question: "How do I report an issue with a delivery?",
    answer: "To report an issue with a delivery, go to your Orders page, find the specific order, and click 'Report Issue'. Select the appropriate category for your issue and provide details about what happened. Our support team will review your report and get back to you within 24 hours."
  },
  {
    id: 5,
    question: "Can I choose which orders to accept?",
    answer: "Yes, you have the flexibility to accept or decline delivery requests based on your availability and preference. However, maintaining a high acceptance rate improves your overall rating and may increase your priority for premium deliveries with higher earnings potential."
  },
  {
    id: 6,
    question: "How is the delivery fee calculated?",
    answer: "Delivery fees are calculated based on several factors including distance, time of day, weather conditions, and order size. The base delivery fee covers a standard distance, with additional compensation for longer distances. You also keep 100% of customer tips."
  },
  {
    id: 7,
    question: "What safety measures should I follow during deliveries?",
    answer: "Always prioritize safety by following traffic rules, wearing appropriate safety gear, and using the in-app navigation. Ensure food items are secured properly during transit. If you feel unsafe during a delivery, you can contact support immediately through the emergency assistance feature in the app."
  },
  {
    id: 8,
    question: "How do I take time off or set my availability?",
    answer: "You can set your availability by toggling your status in the app. When you're ready to work, set your status to 'Available' to receive delivery requests. When you need time off, simply switch to 'Offline'. There's no minimum hour requirement, giving you complete flexibility."
  }
];

const Help: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [openFaqId, setOpenFaqId] = useState<number | null>(null);
  
  // Filter FAQs based on search query
  const filteredFaqs = faqData.filter(faq =>
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Toggle FAQ item
  const toggleFaq = (id: number) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Help & Support</h1>
      
      {/* Search */}
      <div className="relative max-w-2xl mx-auto">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          placeholder="Search for help topics..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="input pl-12 py-3 text-lg"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FAQs */}
        <div className="lg:col-span-2">
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-6">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              {filteredFaqs.length > 0 ? (
                filteredFaqs.map((faq) => (
                  <div key={faq.id} className="border border-gray-200 rounded-lg overflow-hidden">
                    <motion.button
                      className="w-full flex justify-between items-center p-4 text-left bg-white hover:bg-gray-50"
                      onClick={() => toggleFaq(faq.id)}
                    >
                      <span className="font-medium">{faq.question}</span>
                      <ChevronDown 
                        size={18} 
                        className={`transition-transform ${openFaqId === faq.id ? 'rotate-180' : ''}`} 
                      />
                    </motion.button>
                    
                    <AnimatePresence>
                      {openFaqId === faq.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="p-4 pt-0 border-t border-gray-200 text-gray-600">
                            {faq.answer}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No results found for "{searchQuery}".</p>
                  <p className="mt-2 text-sm text-gray-500">Try using different keywords or contact support.</p>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Contact Support */}
        <div className="space-y-6">
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-4">Contact Support</h2>
            
            <div className="space-y-4">
              <motion.a
                href="#"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-4">
                  <MessageCircle size={20} className="text-primary-600" />
                </div>
                <div>
                  <p className="font-medium">Chat Support</p>
                  <p className="text-sm text-gray-500">Available 24/7</p>
                </div>
              </motion.a>
              
              <motion.a
                href="tel:+18001234567"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-secondary-100 flex items-center justify-center mr-4">
                  <Phone size={20} className="text-secondary-600" />
                </div>
                <div>
                  <p className="font-medium">Phone Support</p>
                  <p className="text-sm text-gray-500">1-800-123-4567</p>
                </div>
              </motion.a>
              
              <motion.a
                href="mailto:support@deliverypro.com"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-warning-100 flex items-center justify-center mr-4">
                  <Mail size={20} className="text-warning-600" />
                </div>
                <div>
                  <p className="font-medium">Email Support</p>
                  <p className="text-sm text-gray-500">support@deliverypro.com</p>
                </div>
              </motion.a>
            </div>
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-4">Resources</h2>
            
            <div className="space-y-4">
              <motion.a
                href="#"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center mr-4">
                  <FileText size={20} className="text-gray-600" />
                </div>
                <div>
                  <p className="font-medium">Delivery Guidelines</p>
                  <p className="text-sm text-gray-500">Best practices for deliveries</p>
                </div>
              </motion.a>
              
              <motion.a
                href="#"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center mr-4">
                  <FileText size={20} className="text-gray-600" />
                </div>
                <div>
                  <p className="font-medium">Safety Manual</p>
                  <p className="text-sm text-gray-500">Safety tips and procedures</p>
                </div>
              </motion.a>
              
              <motion.a
                href="#"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center mr-4">
                  <FileText size={20} className="text-gray-600" />
                </div>
                <div>
                  <p className="font-medium">Earnings Explanation</p>
                  <p className="text-sm text-gray-500">How payments work</p>
                </div>
              </motion.a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Help;