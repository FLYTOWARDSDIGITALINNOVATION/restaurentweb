import express from 'express';
import asyncHandler from 'express-async-handler';
import Partner from '../models/Partner.js';
import protect from '../middleware/auth.js';
import upload from '../middleware/upload.js';
import cloudinary from '../config/cloudinary.js';
import fs from 'fs';

const router = express.Router();

// Get partner profile
router.get('/profile', protect, asyncHandler(async (req, res) => {
  const partner = await Partner.findById(req.partner.id).select('-password');
  if (partner) {
    res.json(partner);
  } else {
    res.status(404);
    throw new Error('Partner not found');
  }
}));

// Update partner profile
router.put('/profile', protect, asyncHandler(async (req, res) => {
  const partner = await Partner.findById(req.partner.id);

  if (partner) {
    partner.name = req.body.name || partner.name;
    partner.email = req.body.email || partner.email;
    partner.phone = req.body.phone || partner.phone;
    partner.vehicle = req.body.vehicle || partner.vehicle;
    partner.address = req.body.address || partner.address;
    partner.bankAccount = req.body.bankAccount || partner.bankAccount;
    partner.emergencyContact = req.body.emergencyContact || partner.emergencyContact;

    if (req.body.password) {
      partner.password = req.body.password;
    }

    const updatedPartner = await partner.save();

    res.json({
      _id: updatedPartner._id,
      name: updatedPartner.name,
      email: updatedPartner.email,
      phone: updatedPartner.phone,
      vehicle: updatedPartner.vehicle,
      address: updatedPartner.address,
      bankAccount: updatedPartner.bankAccount,
      emergencyContact: updatedPartner.emergencyContact
    });
  } else {
    res.status(404);
    throw new Error('Partner not found');
  }
}));

// Upload profile image
router.post('/upload-image', protect, upload.single('image'), asyncHandler(async (req, res) => {
  try {
    const partner = await Partner.findById(req.partner.id);
    
    if (!partner) {
      res.status(404);
      throw new Error('Partner not found');
    }

    if (!req.file) {
      res.status(400);
      throw new Error('Please upload an image');
    }

    // Upload to cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: 'delivery-partners',
      width: 300,
      crop: "scale"
    });

    // Delete the file from local storage
    fs.unlinkSync(req.file.path);

    // Update partner profile with new image
    partner.profileImage = result.secure_url;
    await partner.save();

    res.json({
      message: 'Profile image uploaded successfully',
      imageUrl: result.secure_url
    });
  } catch (error) {
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ message: error.message });
  }
}));

// Toggle availability status
router.put('/toggle-availability', protect, asyncHandler(async (req, res) => {
  const partner = await Partner.findById(req.partner.id);

  if (partner) {
    partner.isAvailable = !partner.isAvailable;
    const updatedPartner = await partner.save();
    
    res.json({
      isAvailable: updatedPartner.isAvailable
    });
  } else {
    res.status(404);
    throw new Error('Partner not found');
  }
}));

// Get earnings history
router.get('/earnings', protect, asyncHandler(async (req, res) => {
  // This would typically fetch from an Earnings model
  // For now, returning mock data
  res.json({
    totalEarnings: 830.25,
    pendingPayouts: 120.75,
    weeklyEarnings: [
      { date: '2025-04-10', amount: 245.80 },
      { date: '2025-04-03', amount: 198.50 },
      { date: '2025-03-27', amount: 385.95 }
    ]
  });
}));

export default router;