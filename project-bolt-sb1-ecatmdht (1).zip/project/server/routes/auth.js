import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Partner from '../models/Partner.js';

const router = express.Router();

// Register Partner
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, vehicle } = req.body;

    // Check if partner exists
    let partner = await Partner.findOne({ email });
    if (partner) {
      return res.status(400).json({ message: 'Partner already exists' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create partner
    partner = new Partner({
      name,
      email,
      password: hashedPassword,
      phone,
      vehicle
    });

    await partner.save();

    // Create token
    const token = jwt.sign(
      { partnerId: partner._id },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.status(201).json({
      token,
      partner: {
        id: partner._id,
        name: partner.name,
        email: partner.email,
        phone: partner.phone,
        vehicle: partner.vehicle,
        isAvailable: partner.isAvailable
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Login Partner
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if partner exists
    const partner = await Partner.findOne({ email });
    if (!partner) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, partner.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Create token
    const token = jwt.sign(
      { partnerId: partner._id },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      token,
      partner: {
        id: partner._id,
        name: partner.name,
        email: partner.email,
        phone: partner.phone,
        vehicle: partner.vehicle,
        isAvailable: partner.isAvailable,
        profileImage: partner.profileImage
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;