import mongoose from 'mongoose';

const partnerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true
  },
  vehicle: {
    type: String,
    required: true,
    enum: ['Motorcycle', 'Bicycle', 'Car', 'Scooter', 'On Foot']
  },
  isAvailable: {
    type: Boolean,
    default: false
  },
  profileImage: String,
  address: String,
  licenseNumber: String,
  bankAccount: String,
  emergencyContact: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Partner = mongoose.model('Partner', partnerSchema);

export default Partner;